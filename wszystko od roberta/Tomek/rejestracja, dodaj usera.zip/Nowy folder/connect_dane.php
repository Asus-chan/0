<?php
$host = "localhost";
$user = "root";
$password = "";
$baza = "wilk";
$tabela = "users";
?>